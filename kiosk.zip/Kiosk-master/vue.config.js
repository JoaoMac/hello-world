module.exports = {
    lintOnSave: true,
    devServer: {
        disableHostCheck: true
    },
    productionSourceMap: false,
    pwa: {
        name: 'Kiosk',
        themeColor: '#18303e',
        msTileColor: '#18303e',
        appleMobileWebAppCapable: 'yes',
        appleMobileWebAppStatusBarStyle: '#18303e',
        // configure the workbox plugin
        workboxPluginMode: 'InjectManifest',
        workboxOptions: {
            // swSrc is required in InjectManifest mode.
            swSrc: 'public/service-worker.js',
            // ...other Workbox options...
        }
    }
};
