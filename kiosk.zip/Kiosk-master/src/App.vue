<template>
    <div id="app">
        <app-navbar></app-navbar>
        <router-view></router-view>

    </div>
</template>

<script>
    import navbar from './components/Navbar/Navbar.vue'

    export default {
        name: 'app',
        components: {
            'app-navbar': navbar,

        },
        data: function () {
            return {
                books: [],
                magazines: [],
                existUsers: [],
                user: {}
            };
        },

        created() {
            // Carrega Array dos livros
            if (!localStorage.usersList) {
                this.existUsers = [
                    {
                        'name': 'Admin',
                        'email': 'admin@esmad.com',
                        'pass': 'admin#',

                    }

                ];
                localStorage.setItem("usersList", JSON.stringify(this.existUsers));
            }
            if (!localStorage.books) {
                this.books = [

                    {
                        id: 0,
                        img: 'https://i.postimg.cc/D0mgdWW0/android-intro.jpg',
                        title: 'Android Introdução ao Desenvolvimento de Aplicações',
                        author: 'Ricardo Queirós ',
                        description: 'Tem como principal objetivo ensinar todos aqueles que se estão a iniciar no desenvolvimento de aplicações para dispositivos Android.',
                        ISBN: '9789727227631',
                        number: 4,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 1,
                        img: 'https://i.postimg.cc/1t3csgrB/Intro-web.jpg',
                        title: 'Introdução ao Desenvolvimento Moderno para a Web',
                        author: 'Ricardo Queirós e Filipe Portela ',
                        description: 'Do front-end ao back-end: uma visão global!',
                        ISBN: '9789727228973',
                        number: 5,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 2,
                        img: 'https://i.postimg.cc/k4YN4njm/java8.jpg',
                        title: 'Java 8',
                        author: 'F.Mário Martins',
                        description: 'POO + Construções Funcionais',
                        ISBN: '9789727228386',
                        number: 3,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 3,
                        img: 'https://i.postimg.cc/pLMfycBp/linguagens-web.jpg',
                        title: 'Linguagens WEB',
                        author: 'Alexandre Pereira e Carlos Poupa',
                        description: 'Esta obra, agora em 6ª edição, revista e atualizada, inclui um capítulo novo sobre MySQL e uma secção de programação para telemóveis que utilizem o sistema operativo Android da Google.',
                        ISBN: '9789726189138',
                        number: 2,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 4,
                        img: 'https://i.postimg.cc/J7dK7Qgk/android-desen.jpg',
                        title: 'Android Desenvolvimento de Aplicações com Android Studio',
                        author: 'Ricardo Queirós',
                        description: 'Desenvolvimento de Aplicações com Android Studio',
                        ISBN: '9789727228195 ',
                        number: 3,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 5,
                        img: 'https://i.postimg.cc/mkqSdbMw/design-indus.jpg',
                        title: 'Design Industrial',
                        author: 'Tomás Maldonado',
                        description: 'Livro muito objectivo e de fácil leitura.',
                        ISBN: '9789724413310 ',
                        number: 2,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 6,
                        img: 'https://i.postimg.cc/cHFhn7LP/design-graf.jpg',
                        title: 'FBA. O design gráfico como prática de clarificação',
                        author: 'João Manuel Bicker ',
                        description: 'O que procuro é testar a efectividade de uma intenção, que foi sempre a da FBA',
                        ISBN: '9789724063768',
                        number: 2,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 7,
                        img: 'https://i.postimg.cc/3Jvj8Qms/Multimedia.jpg',
                        title: 'Multimédia e Tecnologias Interativas',
                        author: 'Nuno Magalhães Ribeiro',
                        description: 'Objetivo principal apresentar uma introdução fundamentada, clara, acessível, integrada e abrangente ',
                        ISBN: '9789727227440',
                        number: 3,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 8,
                        img: 'https://i.postimg.cc/q7LXPcyg/fotografia.jpg',
                        title: 'Fotografia Digital - Curso Completo',
                        author: 'Texto Editores',
                        description: 'Aprenda tudo o que precisa de saber em 20 semanas.',
                        ISBN: '9789724750545',
                        number: 2,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },

                    {
                        id: 9,
                        img: 'https://i.postimg.cc/44rLb55T/sound.png',
                        title: 'Inner Sound',
                        author: 'Jonathan Weinel',
                        description: 'altered states of consciousness on audio-visual media',
                        ISBN: '9780190671181',
                        number: 4,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 10,
                        img: 'https://i.postimg.cc/GmvjQnpF/android-profissional.jpg',
                        title: 'Android Profissional',
                        author: 'Ricardo Queirós',
                        description: 'Desenvolvimento moderno com Aplicações',
                        ISBN: '9789727228744 ',
                        number: 3,
                        idiom: 'PT',
                        score:[],
                        comments:[]


                    },
                    {
                        id: 11,
                        img: 'https://i.postimg.cc/NMFTZ3QP/sites-respon.jpg',
                        title: 'Criação Rápida de Sites Responsivos com o Bootstrap',
                        author: 'Ricardo Queirós',
                        description: 'Desenvolvimento de sites e aplicações',
                        ISBN: '9789727228676',
                        number: 5,
                        idiom: 'PT',
                        score:[],
                        comments:[]

                    },
                    {
                        id: 12,
                        img: 'https://i.postimg.cc/vHJzfZG8/desen-android.jpg',
                        title: 'Desenvolvimento de Aplicações Profissionais em Android',
                        author: 'Ricardo Queirós',
                        description: 'Desenvolvimento de aplicações',
                        ISBN: '9789727227969',
                        number: 3,
                        idiom: 'PT',
                        score:[],
                        comments:[]

                    },
                    {
                        id: 13,
                        img: 'https://i.postimg.cc/y65XC8gh/jogos-android.jpg',
                        title: 'Introdução ao Desenvolvimento de Jogos em Android',
                        author: ' Alberto Simões e Ricardo Queirós',
                        description: 'Desenvolvimento de jogos para android',
                        ISBN: '9789727228072 ',
                        number: 2,
                        idiom: 'PT',
                        score:[],
                        comments:[]

                    },
                    {
                        id: 14,
                        img: 'https://i.postimg.cc/PrpyCwsF/bd-android.jpg',
                        title: 'Android Bases de Dados e Geolocalização',
                        author: 'Ricardo Queirós',
                        description: 'Base de dados e Geolocalização',
                        ISBN: '9789727228621',
                        number: 1,
                        idiom: 'PT',
                        score:[],
                        comments:[]

                    },
                    {
                        id: 15,
                        img: 'https://i.postimg.cc/Bb8TPdy1/jogo-un.jpg',
                        title: 'Introdução ao Desenvolvimento de Jogos com Unity',
                        author: 'Alberto Simões ',
                        description: 'desenvolvimento de jogos em unity',
                        ISBN: '9789727228836',
                        number: 3,
                        idiom: 'PT',
                        score:[],
                        comments:[]

                    },
                    {
                        id: 16,
                        img: 'https://i.postimg.cc/43ZQ22Kr/foto2.jpg',
                        title: 'Fotografia Luz, exposição, composição, equipamento',
                        author: 'Joel Santos',
                        description: 'fotografia',
                        ISBN: '9789896150990',
                        number: 1,
                        idiom: 'PT',
                        score:[],
                        comments:[]

                    },
                    {
                        id: 17,
                        img: 'https://i.postimg.cc/mkF9g7zY/tec-multi.jpg',
                        title: 'Tecnologias de Compressão Multimédia',
                        author: 'Nuno Magalhães Ribeiro e José Torres',
                        description: 'introdução fundamentada, clara, acessível e abrangente aos conceitos e tecnologias relacionadas com a multimedia',
                        ISBN: '9789727226337',
                        number: 2,
                        idiom: 'PT',
                        score:[],
                        comments:[]

                    },
                    {
                        id: 18,
                        img: 'https://i.postimg.cc/W3yrV53p/sql.jpg',
                        title: 'SQL - Structured Query Language',
                        author: 'Luís Damas',
                        description: 'nova edição atualizada de uma obra fundamental e de leitura obrigatória que aborda a temática do acesso a bases de dados através da linguagem SQL',
                        ISBN: '9789727228294',
                        number: 3,
                        idiom: 'PT',
                        score:[],
                        comments:[]

                    },
                ];
                localStorage.setItem("books", JSON.stringify(this.books));
            } else {
                this.books = JSON.parse(localStorage.getItem("books"));
            }

           

        }
    }
</script>

<style lang="scss">
    @import "./assets/scss/main";

    #app {
        font-family: PT, serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        text-align: center;
    }

    /* Custom style */

    .button-light {
        background-color: #DFDFDF;
    }

    .button:hover {
        opacity: .7;
    }

    .navbar-item.is-language {
        display: inline-flex !important;
    }
</style>

