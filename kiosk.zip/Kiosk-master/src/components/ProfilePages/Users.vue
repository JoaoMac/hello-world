<template>
    <section>
    <div style="margin: 4%" v-if="hasAdminLogin">
        <h1 class="left-text title" style="padding-bottom: 2%" v-if="this.users.length!==1">Utilizadores</h1>
        <div class="columns is-multiline">
            <div class="column column-flex" v-for="(user, index) in users.slice(1)">
                <div class="card card-size">
                    <div style="padding:10px">
                        <div class="columns">
                            <div class="column is-4">
                                <h1 class="left-text subtitle"><b>Nome:</b></h1>
                            </div>
                            <div class="column is-2-mobile">
                                <p>{{user.name}}</p>
                            </div>
                        </div>
                        <div class="columns">
                            <div class="column is-4">
                                <h1 class="left-text subtitle"><b>Email:</b></h1>
                            </div>
                            <div class="column is-2-mobile">
                                <p>{{user.email}}</p>

                            </div>
                        </div>
                    </div>
                    <footer class="card-footer">
                        <a class="card-footer-item button-color" @click="openReserves(user)"><b>Ver Reservas</b></a>
                        <a class="card-footer-item button-color-red" @click="removeUser(user,index)"><b>Remover</b></a>
                    </footer>
                </div>
            </div>
        </div>


        <div class="center-screen-desktop" v-if="this.users.length===1">
            <h1 class="title has-text-centered">Não há utilizadores registados</h1>
        </div>


    </div>
        <div class="center-screen-desktop" v-else>
            <h1 class="title has-text-centered">Não tem privilégios para aceder a esta página</h1>
        </div>
    <app-reservesModal v-if="this.$store.getters['getOpen']"></app-reservesModal>
    </section>
</template>

<script>
    import ReservesModal from './../HomePages/ReservesModal.vue'
    import {openReserves} from '../../mixins/modal/openReserves.js'
    export default {
        name: "Users",
        mixins:[openReserves],

        components: {
            'app-reservesModal': ReservesModal


        },
        data: function () {
            return {
                users: JSON.parse(localStorage.getItem("usersList")),
                hasLogin: sessionStorage.isLogged,
                hasAdminLogin: sessionStorage.adminIsLogged,
                isOpen:false

            };
        },

        methods: {
            removeUser(user,index) {
                console.log(user)
                this.$dialog.confirm({
                    title: `Remover Utilizador`,
                    message: `Tem a certeza que pretende <b>remover</b> ${user.name}?`,
                    confirmText: 'Remover Utilizador',
                    cancelText:'Cancelar',
                    type: 'is-danger-dialog',
                    hasIcon: true,
                    onConfirm: () => {
                        this.users.splice(index + 1,1);
                        localStorage.setItem("usersList", JSON.stringify(this.users));
                    }
                })

            }

        }


    }

</script>

<style scoped>

    .left-text {
        text-align: left;

    }

    .card-size {
        display: block;
        height: auto;
        width: 300px;

    }

    .column-flex {
        flex-grow: 0 !important;
        -webkit-flex-grow: 0 !important;
    }

    .button-color-red {
        background-color: darkred;
        text-decoration-color: white
    }

    .button-color {
        background-color: #18303e;
        text-decoration-color: white
    }

    .center-screen-desktop {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);

    }


</style>