<template>
    <section>
    <div v-if="hasLogin || hasAdminLogin">
        <div class="form card center-screen-desktop">
            <h3 class="title">
                Perfil
            </h3>
            <div class="control card-content">
                <b-field label="Nome">
                    <p v-if="hasLogin">{{profileInfo[0].name}}</p>
                    <p v-if="hasAdminLogin">{{adminInfo[0].name}}</p>
                </b-field>
                <br>
                <b-field label="Email">
                    <p v-if="hasLogin">{{profileInfo[0].email}}</p>
                    <p v-if="hasAdminLogin">{{adminInfo[0].email}}</p>
                </b-field>
                <br>
                <b-field label="Password" v-if="hasLogin">
                    <b-input type="password" v-model="password"></b-input>
                </b-field>
                <b-field label="Confirmar Password" v-if="hasLogin">
                    <b-input type="password" v-model="password2"></b-input>
                </b-field>

                <div class="has-text-centered" v-if="hasLogin">
                    <button class="button button-color has-text-white" @click="change">
                        Alterar Password
                    </button>
                </div>

            </div>
        </div>


    </div>
        <div class="center-screen-desktop" v-else>
            <h1 class="title has-text-centered">Inicie sessão para aceder a esta página</h1>
        </div>
    </section>
</template>

<script>

    export default {
        data() {
            return {
                hasLogin: sessionStorage.isLogged,
                hasAdminLogin: sessionStorage.adminIsLogged,
                profileInfo: JSON.parse(sessionStorage.getItem("isLogged")),
                users: JSON.parse(localStorage.getItem("usersList")),
                adminInfo: JSON.parse(sessionStorage.getItem("adminIsLogged")),
                password: null,
                password2: null,
            }
        },

        methods: {
            change() {
                const password = this.password

            if (this.password !==this.password2) {

                    this.$dialog.alert({
                        title: "Erro",
                        type: 'is-danger-dialog',
                        message: "As duas passwords não são iguais"
                    })
                }else if(this.password===this.profileInfo[0].pass){

                this.$dialog.alert({
                    title: "Erro",
                    type: 'is-danger-dialog',
                    message: "A Password nova tem que ser diferente da antiga"
                })

            } else if (password != null) {

                    this.profileInfo[0].pass= password

                    this.$dialog.alert({
                        title: "Sucesso",
                        type: 'is-success',
                        message: "Password alterada com sucesso"
                    })

                    sessionStorage.setItem("isLogged", JSON.stringify(this.profileInfo));
                    let res = this.users.map(obj => this.profileInfo.find(o => o.email === obj.email) || obj);
                    console.log(res);
                    localStorage.setItem("usersList", JSON.stringify(res))
                }
                else {
                    this.$dialog.alert({
                        title: "Erro",
                        type: 'is-danger-dialog',
                        message: "Password não pode estar vazia"
                    })
                }

            }
        },


    }
</script>

<style scoped>

    .form {
        padding-top: 30px;
        margin: auto;
        width: 600px;
    }

    .title {
        font-size: 25px;
    }

    .center-screen-desktop {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);

    }

    .button-color {
        background-color: #18303e;
    }


</style>
