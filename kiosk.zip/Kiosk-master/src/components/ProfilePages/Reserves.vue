<template>
    <section>
        <div style="margin: 4%" v-if="hasLogin">

            <h1 class="has-text-left title" style="margin-bottom: 2%" v-if="this.user[0].reserves.length!==0">
                Reservas</h1>
            <div class="columns is-multiline">
                <div class="column column-flex" v-for="(book, index) in user[0].reserves">
                    <div class="card ">
                        <div class="card-image cursor cover-size">
                            <div class="container" @click="open(book)">
                                <img :src="book.img" class="cover-size">
                                <div class="overlay">
                                    <i class="mdi mdi-magnify has-text-white"></i>
                                </div>
                            </div>
                        </div>
                        <footer class="card-footer">
                            <a class="card-footer-item button-color-red" @click="removeReserve(book,index)"><b>Cancelar
                                Reserva</b></a>
                        </footer>
                    </div>
                </div>

            </div>

            <div class="center-screen-desktop" v-if="this.user[0].reserves.length===0">
                <h1 class="title has-text-centered">Não tem reservas</h1>
            </div>

        </div>


        <app-modal v-if="this.$store.getters['getOpen']"></app-modal>
    </section>
</template>

<script>
    import {openModal} from '../../mixins/modal/open.js'
    import BookModal from './../HomePages/BookModal.vue'

    export default {
        name: "Favorites",
        mixins: [openModal],
        components: {
            'app-modal': BookModal,
        },
        data: function () {
            return {
                books: JSON.parse(localStorage.getItem("books")),
                user: JSON.parse(sessionStorage.getItem("isLogged")),
                users: JSON.parse(localStorage.getItem("usersList")),
                hasLogin: sessionStorage.isLogged,
                hasAdminLogin: sessionStorage.adminIsLogged,


            };
        },


        methods: {


            removeReserve(book, index) {

                this.$dialog.confirm({
                    title: `Cancelar`,
                    message: `Tem a certeza que pretende cancelar esta reserva?`,
                    confirmText: 'Cancelar Reserva',
                    cancelText: 'Cancelar',
                    type: 'is-danger-dialog',
                    hasIcon: true,
                    onConfirm: () => {

                        book.number = book.number+1
                        this.user[0].reserves.splice(index, 1);
                        sessionStorage.setItem("isLogged", JSON.stringify(this.user));
                        let res = this.users.map(obj => this.user.find(o => o.email === obj.email) || obj);
                        console.log(res);
                        localStorage.setItem("usersList", JSON.stringify(res))
                       let res2 = this.books.map(obj => this.user[0].reserves.find(o => o.id === obj.id) || obj);
                        console.log(res);
                        localStorage.setItem("books", JSON.stringify(res2))
                    }
                })

            },

        }
    }


</script>

<style scoped>


    .cover-size {
        display: block;
        height: 280px;
        width: 200px;

    }

    .column-flex {
        flex-grow: 0 !important;
        -webkit-flex-grow: 0 !important;
    }

    .cursor {
        cursor: pointer;
    }

    .button-color-red {
        background-color: darkred;
        text-decoration-color: white
    }


    .container {
        position: relative;
        width: 100%;
    }

    .overlay {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        height: 100%;
        width: 100%;
        opacity: 0;
        transition: .3s ease;
        background-color: #18303e;
    }

    .container:hover .overlay {
        opacity: 0.7;
    }

    .mdi-magnify {

        font-size: 100px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        text-align: center;
    }

    .center-screen-desktop {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);

    }




</style>