<template>
    <section>
    <div class="form card center-screen-desktop" v-if="!hasLogin ||!hasAdminLogin">
        <h3 class="title">
            Registar
        </h3>
        <div class="control card-content">
            <b-field label=" Nome">
                <b-input type="text" v-model="name"></b-input>
            </b-field>
            <b-field label="Email">
                <b-input type="email" v-model="email"></b-input>
            </b-field>
            <b-field label="Password">
                <b-input type="password" v-model="password"></b-input>
            </b-field>
            <b-field label="Confirmar Password">
                <b-input type="password" v-model="password2"></b-input>
            </b-field>
            <br>
            <div class="has-text-centered">
                <button class="button button-color has-text-white" @click="signUp">
                    Registar
                </button>
            </div>
            <b-loading :is-full-page="isFullPage" :active.sync="isLoading" :can-cancel="true"></b-loading>
        </div>
    </div>
        <div class="center-screen-desktop" v-else>
            <h1 class="title has-text-centered">Já tem sessão iniciada</h1>
        </div>
    </section>
</template>

<script>

    export default {
        data() {
            return {
                name: null,
                email: null,
                password: null,
                password2: null,
                isLoading: false,
                isFullPage: true,
                hasLogin: sessionStorage.isLogged,
                hasAdminLogin: sessionStorage.adminIsLogged,
                existUsers:JSON.parse(localStorage.getItem("usersList")),
                user: {},


            }
        },

        methods: {


            signUp() {

                const name = this.name
                const email = this.email
                const password = this.password
                let emailExists = false
                this.isLoading = true;
                this.existUsers = JSON.parse(localStorage.getItem("usersList"))


                if (this.name == null || this.email == null || this.password == null || this.password2 == null) {
                    this.isLoading = false
                    this.$dialog.alert({
                        title: "Erro",
                        type: 'is-danger-dialog',
                        message: "Preencha todos os campos corretamente"
                    })
                }
                else if (this.password != this.password2) {
                    this.isLoading = false
                    this.$dialog.alert({
                        title: "Erro",
                        type: 'is-danger-dialog',
                        message: "As duas passwords não são iguais"
                    })
                }


                else {
                    for (let i = 0; i < this.existUsers.length; i++) {
                        console.log(this.existUsers[i].email)
                        if (email === this.existUsers[i].email) {
                            this.isLoading = false
                            this.$dialog.alert({
                                title: "Erro",
                                type: 'is-danger-dialog',
                                message: "Email já existente"
                            })
                            emailExists = true


                        }
                    }

                    if (!emailExists) {
                        this.isLoading = false
                        this.user =

                            {
                                'name': name,
                                'email': email,
                                'pass': password,
                                'favs': [],
                                'reserves':[],
                                'notif':[]


                            };


                        this.existUsers.push(this.user)
                        localStorage.setItem("usersList", JSON.stringify(this.existUsers));

                        this.$dialog.alert({
                            title: "Sucesso",
                            type: 'is-success',
                            message: "Registo efectuado com sucesso",
                            onConfirm:() => window.location.pathname = '/'

                        })

                    }


                }


            },
        },

    }
</script>

<style scoped>


    .form {
        padding-top: 30px;
        margin: auto;
        width: 600px;
    }

    .title {
        font-size: 25px;
    }

    .card {
        margin-bottom: 5%;
    }

    .center-screen-desktop {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);

    }

    .button-color {
        background-color: #18303e;
    }
</style>