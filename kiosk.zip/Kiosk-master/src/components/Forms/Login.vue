<template>
    <section>
        <div class="form card center-screen-desktop" v-if="!hasLogin && !hasAdminLogin">
            <h3 class="title">
                Login
            </h3>
            <div class="control card-content">
                <b-field label="Email">
                    <b-input type="email" v-model="email"></b-input>
                </b-field>
                <b-field label="Password">
                    <b-input type="password" v-model="password"></b-input>
                </b-field>
                <br>
                <div class="has-text-centered">
                    <button class="button button-color has-text-white" @click="login">
                        Entrar
                    </button>
                </div>

            </div>
        </div>
        <div class="center-screen-desktop" v-else>
            <h1 class="title has-text-centered">Já tem sessão iniciada</h1>
        </div>
    </section>
</template>

<script>

    export default {
        data() {
            return {
                email: null,
                password: null,
                usersList: JSON.parse(localStorage.getItem("usersList")),
                logged: [],
                adminLogged: [],
                hasLogin: sessionStorage.isLogged,
                hasAdminLogin: sessionStorage.adminIsLogged

            }
        },

        methods: {


            login() {
                const email = this.email
                const password = this.password


                console.log(this.usersList.length)

                for (let i = 0; i < this.usersList.length; i++) {
                    // check is user input matches username and password of a current index of the objPeople array
                    if (email === this.usersList[i].email && password === this.usersList[i].pass) {
                        console.log(this.usersList[i].name + " is logged in!!!")
                        console.log(this.usersList[i])
                        if (this.usersList[i].email !== 'admin@esmad.com') {
                            this.logged.push(this.usersList[i])
                            sessionStorage.setItem("isLogged", JSON.stringify(this.logged));
                            if (this.$router.history.current.path === "/login") {
                                window.location.pathname = '/'
                            }
                        } else if (this.usersList[i].email === 'admin@esmad.com') {

                            this.adminLogged.push(this.usersList[i])
                            sessionStorage.setItem("adminIsLogged", JSON.stringify(this.adminLogged));
                            if (this.$router.history.current.path === "/login") {
                                window.location.pathname = '/'
                            }
                        }

                        // stop the function if this is found to be true
                        return

                    }
                }


                this.$dialog.alert({
                    title: "Erro",
                    type: 'is-danger-dialog',
                    message: "Dados incorretos!"
                })


            }

        }
    }
</script>

<style scoped>

    .form {
        padding-top: 30px;
        margin: auto;
        width: 600px;
    }

    .title {
        font-size: 25px;
    }

    .center-screen-desktop {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);

    }

    .button-color {
        background-color: #18303e;
    }

</style>
