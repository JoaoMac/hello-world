<template>
    <header>
        <!--navbar-->
        <nav class="navbar">
            <div class="navbar-brand">

                <img @click="goToPage('/')" class="cursor" :src="getImageSrc()">

                <div role="button" @click="showMobileMenu = !showMobileMenu" class="navbar-burger has-text-white"
                     :class="{'is-active':showMobileMenu}">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </div>
            </div>

            <div id="navMenu" class="navbar-menu" :class="{'is-active': showMobileMenu}">
                <div class="navbar-start">
                </div>
                <div class="navbar-end">
                    <div role="button" class="navbar-item  is-hoverable " v-if="hasLogin">
                        <a class="navbar-item">
                            <div class="columns">
                                <div class="column">
                                    <i class="mdi mdi-bell " :class="{'has-text-white': !showMobileMenu, 'has-text-black':showMobileMenu}"></i>
                                </div>
                                <div class="column is-3">
                                    <p :class="{'has-text-white': !showMobileMenu, 'has-text-black':showMobileMenu}">{{userName[0].notif.length}}</p>
                                </div>
                            </div>
                        </a>
                        <div class="navbar-dropdown drop ">
                            <div class="columns" v-for="(notif, index) in userName[0].notif">

                                <div class="column is-8" style="margin: 10px;">
                                    <p class="has-text-black has-text-left"><b>{{notif.notif}}</b></p>
                                    <p class="has-text-black has-text-left">{{notif.date}}</p>
                                    <hr class="dropdown-divider">
                                </div>
                                <div class="column is-3 ">
                                    <button class="button button-color-red " :class="{'has-text-white': !showMobileMenu, 'has-text-black':showMobileMenu}" style="margin-top: 3%" @click="removeNotif(notif,index)">
                                       Apagar
                                    </button>

                                </div>

                            </div>

                        </div>
                    </div>


                    <a class="navbar-item" @click="goToPage('/reserves')" :class="{'has-text-white': !showMobileMenu, 'has-text-black':showMobileMenu}"v-if="hasLogin">
                        Reservas
                    </a>

                    <a class="navbar-item" :class="{'has-text-white': !showMobileMenu, 'has-text-black':showMobileMenu}" @click="goToPage('/favorites')" v-if="hasLogin">
                        Favoritos
                    </a>


                    <a class="navbar-item" @click="goToPage('/users')" :class="{'has-text-white': !showMobileMenu, 'has-text-black':showMobileMenu}"v-if="hasAdminLogin">
                        Utilizadores
                    </a>
                    <a class="navbar-item" @click="goToPage('/signup')":class="{'has-text-white': !showMobileMenu, 'has-text-black':showMobileMenu}" v-if="!hasLogin && !hasAdminLogin">
                        Registar
                    </a>
                    <a class="navbar-item" @click="goToPage('/login')" :class="{'has-text-white': !showMobileMenu, 'has-text-black':showMobileMenu}"v-if="!hasLogin && !hasAdminLogin">
                        Entrar
                    </a>

                    <div role="button" class="navbar-item  is-hoverable margin-right" v-if="hasLogin || hasAdminLogin">
                        <a class="navbar-link" :class="{'has-text-white': !showMobileMenu, 'has-text-black':showMobileMenu}">
                            <p v-if="hasLogin">{{userName[0].name}}</p>
                            <p v-if="hasAdminLogin">{{adminName[0].name}}</p>
                        </a>
                        <div class="navbar-dropdown is-right">
                            <a class="navbar-item has-text-black " @click="goToPage('/profile')">Perfil</a>

                            <a class="navbar-item has-text-black" @click="logOut">LogOut</a>
                        </div>
                    </div>


                    <!--Adicionar dropdown notificações, user(logout e perfil) -->
                </div>
            </div>
        </nav>
    </header>
</template>

<script>
    import {goToPage} from '../../mixins/navbar/goToPage'

    export default {
        name: "Navbar",
        mixins: [goToPage],
        data() {
            return {
                hasLogin: sessionStorage.isLogged,
                hasAdminLogin: sessionStorage.adminIsLogged,
                userName: JSON.parse(sessionStorage.getItem("isLogged")),
                adminName: JSON.parse(sessionStorage.getItem("adminIsLogged")),
                users: JSON.parse(localStorage.getItem("usersList")),
                showMobileMenu: false
            }
        },

        methods: {
            removeNotif(notif, index) {


                        this.userName[0].notif.splice(index, 1);
                        sessionStorage.setItem("isLogged", JSON.stringify(this.userName));
                        let res = this.users.map(obj => this.userName.find(o => o.email === obj.email) || obj);
                        localStorage.setItem("usersList", JSON.stringify(res))


            },

            getImageSrc: function () {
                return require(`../../assets/images/logo/${"logo.png"}`)
            },

            logOut() {
                sessionStorage.removeItem('adminIsLogged')
                sessionStorage.removeItem('isLogged')

                window.location.pathname = '/'
            }

        },
    }
</script>

<style scoped>

    .navbar {
        border-bottom: rgb(235, 235, 235) 2px solid !important;
        background-color: #18303e;
    }

    .navbar-item {
        line-height: 1.5;
    }

    span {
        margin-left: 5px;
        margin-right: 5px;
    }

    .cursor {
        cursor: pointer;
        width: auto;
        height: 50px;
        margin-left: 20px;
        margin-top: 10px;
        margin-bottom: 10px;
    }

    .margin-right {
        margin-right: 5%;
    }

    .mdi-bell {

        font-size: 20px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        text-align: center;
    }

    .drop {

       width:500%!important;
    }

    .button-color-red {
        background-color: darkred;
        text-decoration-color: white
    }

</style>