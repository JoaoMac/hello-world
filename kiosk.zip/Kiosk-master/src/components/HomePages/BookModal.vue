<template>
    <section style="font-size: 20px;">
        <!--Modal-->
        <div class="modal is-active">
            <div class="modal-background"></div>
            <div class="modal-card">
                <header class="modal-card-head" style=" background-color: #18303e">
                    <p class="modal-card-title has-text-left has-text-white">
                        Informações
                    </p>
                    <button class="delete" aria-label="close" @click="close"></button>
                </header>
                <section class="modal-card-body">
                    <div class="columns">

                        <!--Desktop-->
                        <div class="column is-4 ">
                            <img class="cover-size" width="150" :src="book.img">
                        </div>

                        <div class="column has-text-left">
                            <p class="has-text-black p-padding"><b>Titulo: </b>
                                {{book.title}}</p>
                            <p class="has-text-black p-padding"><b>Autores: </b>
                                {{book.author}}</p>
                            <p class="has-text-black p-padding"><b>Descrição: </b>
                                {{book.description}}</p>
                            <p class="has-text-black p-padding"><b>ISBN: </b> {{book.ISBN}}
                            </p>
                            <p class="has-text-black p-padding"><b>Idioma: </b> {{book.idiom}}
                            </p>
                            <div v-if="this.$route.path !== '/reserves' && hasLogin">
                                <p class="has-text-black p-padding">
                                    <b>Avaliação: </b> {{avg}}

                                </p>
                                <p class="has-text-black p-padding" s>
                                    <b>Comentários: </b>
                                </p>

                                <div class="color-div has-text-white" v-for="comment in book.comments">
                                    <div style="margin:10px">
                                        <p>{{comment.comment}}</p>

                                        <p style="font-size: 12px">{{comment.user}}</p>

                                        <p style="font-size: 12px">{{comment.date}}</p>
                                    </div>
                                </div>


                            </div>
                            <div v-if="this.$route.path === '/reserves'">
                                <p class="has-text-black p-padding"
                                >
                                    <b>Avaliar: </b>
                                </p>
                                <div class="block" v-if="this.$route.path === '/reserves'">
                                    <b-radio v-model="radio"
                                             native-value=1
                                             type="is-dialog">
                                        1
                                    </b-radio>
                                    <b-radio v-model="radio"
                                             native-value=2
                                             type="is-dialog">
                                        2
                                    </b-radio>
                                    <b-radio v-model="radio"
                                             native-value=3
                                             type="is-dialog">
                                        3
                                    </b-radio>
                                    <b-radio v-model="radio"
                                             native-value="4"
                                             type="is-dialog">
                                        4
                                    </b-radio>
                                    <b-radio v-model="radio"
                                             native-value="5"
                                             type="is-dialog">
                                        5
                                    </b-radio>
                                </div>
                                <p>{{radio}}</p>
                                <p v-if="this.$route.path === '/reserves'" class="has-text-black p-padding">
                                    <b>Comentar: </b>
                                </p>
                                <b-input type="textarea" v-if="this.$route.path === '/reserves'"
                                         v-model="desc"></b-input>
                                <p>{{desc}}</p>
                                <button v-if="this.$route.path === '/reserves'"
                                        class="button button-color has-text-white "
                                        @click="rateComment(book)">
                                    Enviar comentário e Avaliação
                                </button>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
        </div>


    </section>
</template>

<script>
    import {openModal} from '../../mixins/modal/open.js'


    export default {
        name: "BookModal",
        mixins: [openModal],

        data() {
            return {
                radio: null,
                desc: null,
                books: JSON.parse(localStorage.getItem("books")),
                hasLogin: sessionStorage.isLogged,
                hasAdminLogin: sessionStorage.adminIsLogged,
                user: JSON.parse(sessionStorage.getItem("isLogged")),
                book: this.$store.getters['getSelectedBook'],
                score:[],
                sum:0,
                avg:0


            }
        },

create(){


// dividing by 0 will return Infinity
// arr must contain at least 1 element to use reduce


},



        methods: {
            rateComment(book) {

                if (this.radio === null && this.desc === null) {
                    this.$toast.open({
                        message: `Preencha a avaliação e os comentários`,
                        type: 'is-danger-dialog'
                    })

                } else {
                    this.book.score.push(this.radio)


                    this.comment =
                        {
                            'user': this.user[0].name,
                            'date': new Date().toLocaleDateString(),
                            'comment': this.desc

                        };
                    this.book.comments.push(this.comment)

                    let res2 = this.books.map(x => x.id === book.id ? book : x)
                    console.log(res2);
                    localStorage.setItem("books", JSON.stringify(res2))
                    this.$toast.open({
                        message: `Comentário e avaliação guardado com sucesso`,
                        type: 'is-success'
                    })
                    if (this.book.score.length)
                    {
                        this.sum = this.score.reduce(function(a, b) { return a + b; });
                        this.avg = this.sum / this.book.score.length;
                    }
                    window.location.pathname = '/reserves'
                }


            }
        }


    }
</script>

<style scoped>

    .cover-size {
        height: 280px;
        width: 200px;

    }

    .button-color {
        background-color: #18303e;
        margin-top: 20px;
    }

    .p-padding {
        padding-bottom: 10px;
    }

    .color-div {
        background-color: #18303e;
        margin-bottom: 10px;
    }


</style>