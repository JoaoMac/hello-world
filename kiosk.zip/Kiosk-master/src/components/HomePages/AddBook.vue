<template>
    <section style="font-size: 20px;">
        <!--Modal-->
        <div class="modal is-active">
            <div class="modal-background"></div>
            <div class="modal-card">
                <header class="modal-card-head" style=" background-color: #18303e">
                    <p class="modal-card-title has-text-left has-text-white">
                        Adicionar Livro
                    </p>
                    <button class="delete" aria-label="close" @click="close"></button>
                </header>
                <section class="modal-card-body">
                    <div class="columns">

                        <!--Desktop-->
                        <div class="column is-4 ">
                            <img class="cover-size" width="150" :src="link">
                            <p class="has-text-black p-padding"><b>Link da Imagem</b></p>
                            <b-input type="text" v-model="link"></b-input>


                        </div>

                        <div class="column has-text-left">
                            <p class="has-text-black p-padding"><b>Titulo</b></p>
                            <b-input v-model="title"></b-input>
                            <p class="has-text-black p-padding"><b>Autores</b></p>
                            <b-input v-model="authors"></b-input>
                            <p class="has-text-black p-padding"><b>Descrição</b></p>
                            <b-input type="textarea" v-model="desc"></b-input>
                            <p class="has-text-black p-padding"><b>ISBN</b></p>
                            <b-input v-model="ISBN"></b-input>
                            <p class="has-text-black p-padding"><b>Idioma</b></p>
                            <b-input v-model="idiom"></b-input>
                            <p class="has-text-black p-padding"><b>Exemplares disponíves</b></p>
                            <b-input type="number" v-model="available"></b-input>

                            <button class="button button-color has-text-white " @click="addBook">
                                Adicionar Livro
                            </button>

                        </div>
                    </div>
                </section>

            </div>
        </div>


    </section>
</template>

<script>
    import {openAdd} from '../../mixins/modal/openAdd.js'


    export default {
        name: "AddModal",
        mixins: [openAdd],
        data() {
            return {
                title: null,
                authors: null,
                desc: null,
                ISBN: null,
                idiom: null,
                link: null,
                available: null,
                books: JSON.parse(localStorage.getItem("books")),
                book: {}


            }
        },
        created() {
            console.log(this.books[this.books.length - 1])

        },
        methods: {


            addBook() {

                const title = this.title
                const authors = this.authors
                const ISBN = this.ISBN
                const desc = this.desc
                const idiom = this.idiom
                const link = this.link
                const available = this.available
                let bookExists = false


                if (this.title == null || this.authors == null || this.ISBN == null || this.desc == null || this.idiom == null || this.link == null) {
                    this.$dialog.alert({
                        title: "Erro",
                        type: 'is-danger',
                        message: "Preencha todos os campos corretamente"
                    })
                }

                else {
                    for (let i = 0; i < this.books.length; i++) {
                        if (title === this.books[i].title && authors === this.books[i].author) {
                            this.$dialog.alert({
                                title: "Erro",
                                type: 'is-danger-dialog',
                                message: "Livro já existe"
                            })
                            bookExists = true


                        }
                    }

                    if (!bookExists) {
                        let idBook = this.books[this.books.length - 1].id
                        this.book =

                            {
                                'id': idBook + 1,
                                'img': link,
                                'title': title,
                                'author': authors,
                                'description': desc,
                                'ISBN': ISBN,
                                'number': available,
                                'idiom': idiom,
                                'score': [],
                                'comments':[]


                            };


                        this.books.push(this.book)
                        localStorage.setItem("books", JSON.stringify(this.books));

                        this.$dialog.alert({
                            title: "Sucesso",
                            type: 'is-success',
                            message: "Livro guardado com sucesso",
                            onConfirm: () => window.location.pathname = '/'

                        })

                    }


                }


            },
        },


    }
</script>

<style scoped>

    .cover-size {
        height: 280px;
        width: 200px;

    }

    .p-padding {
        padding-bottom: 10px;
    }

    .button-color {
        background-color: #18303e;
        margin-top: 20px;
    }


</style>