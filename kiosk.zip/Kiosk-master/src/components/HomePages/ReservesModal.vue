<template>
    <section style="font-size: 20px;">
        <!--Modal-->
        <div class="modal is-active">
            <div class="modal-background"></div>
            <div class="modal-card">
                <header class="modal-card-head" style=" background-color: #18303e">
                    <p class="modal-card-title has-text-left has-text-white">
                        Reservas de {{user[0].name}}
                    </p>
                    <button class="delete" aria-label="close" @click="close"></button>
                </header>
                <section class="modal-card-body">
                    <div class="columns is-multiline">
                        <div class="column column-flex" v-for="(book, index) in user[0].reserves">
                            <div class="card ">
                                <div class="card-image cover-size">
                                    <img :src="book.img" class="cover-size">
                                </div>
                                <footer class="card-footer">
                                    <a class="card-footer-item button-color-red" @click="removeReserve(book,index)"><b>Apagar</b></a>
                                    <a class="card-footer-item button-color" @click=notify><b>Notificar</b></a>
                                </footer>
                            </div>


                        </div>
                        <h1 class="title has-text-centered" v-if="this.user[0].reserves.length===0">Não tem
                            reservas</h1>
                    </div>
                </section>

            </div>
        </div>
    </section>
</template>

<script>
    import {openReserves} from '../../mixins/modal/openReserves.js'


    export default {
        name: "BookModal",
        mixins: [openReserves],


        data: function () {
            return {
                books: JSON.parse(localStorage.getItem("books")),
                users: JSON.parse(localStorage.getItem("usersList")),
                user: [],
                notification: {},
                isOpen: false

            };
        },


        created() {
            this.user.push(this.$store.getters['getSelectedUser'])


            console.log(this.user)

        },

        methods: {


            removeReserve(book, index) {
                /*console.log(book.number+1)
                                book.number = book.number + 1*/
                this.$dialog.confirm({
                    title: `Cancelar`,
                    message: `Tem a certeza que pretende apagar esta reserva?`,
                    confirmText: 'Apagar Reserva',
                    cancelText: 'Cancelar',
                    type: 'is-danger-dialog',
                    hasIcon: true,
                    onConfirm: () => {
                        if (this.user[0].notif.length === 0) {

                            this.user[0].reserves.splice(index, 1);
                            this.notification =
                                {
                                    'id': 0,
                                    'notif': `A sua reserva ${book.title} foi apagada pelo Administrador`,
                                    'date': new Date().toLocaleDateString()
                                }
                        } else {
                            let idNum =this.user[0].notif[this.user[0].notif.length-1].id
                            this.user[0].reserves.splice(index, 1);
                            this.notification =
                                {
                                    'id': idNum + 1,
                                    'notif': `A sua reserva ${book.title} foi apagada pelo Administrador`,
                                    'date': new Date().toLocaleDateString()
                                }


                        }
                        this.user[0].notif.push(this.notification)
                        let res = this.users.map(obj => this.user.find(o => o.email === obj.email) || obj);
                        console.log(res);
                        localStorage.setItem("usersList", JSON.stringify(res))
                        let res2 = this.books.map(obj => this.user[0].reserves.find(o => o.id === obj.id) || obj);
                        console.log(res);
                        localStorage.setItem("books", JSON.stringify(res2))


                    }
                })

            },

            notify() {
                let idNum =this.user[0].notif[this.user[0].notif.length-1].id
                this.$dialog.prompt({
                    message: `Notificação`,
                    type: 'is-dialog',
                    inputAttrs: {
                        placeholder: 'Notificação...',

                    },
                    onConfirm: (value) => {
                        if (value !== null &&this.user[0].notif.length === 0 ) {
                            this.notification =
                                {
                                    'id': 0,
                                    'notif': value,
                                    'date': new Date().toLocaleDateString()


                                };

                            this.user[0].notif.push(this.notification)
                            let res = this.users.map(obj => this.user.find(o => o.email === obj.email) || obj);
                            console.log(res);
                            localStorage.setItem("usersList", JSON.stringify(res))
                            this.$toast.open({
                                message: `Notificação enviada com sucesso`,
                                type: 'is-success'
                            })

                        } else if (value === null) {

                            this.$dialog.alert({
                                title: "Erro",
                                type: 'is-danger-dialog',
                                message: "Notificação vazia"
                            })
                        }else if(value !== null &&this.user[0].notif.length > 0 ){

                            this.notification =
                                {
                                    'id': idNum +1,
                                    'notif': value,
                                    'date': new Date().toLocaleDateString()

                                };

                            this.user[0].notif.push(this.notification)
                            let res = this.users.map(obj => this.user.find(o => o.email === obj.email) || obj);
                            console.log(res);
                            localStorage.setItem("usersList", JSON.stringify(res))
                            this.$toast.open({
                                message: `Notificação enviada com sucesso`,
                                type: 'is-success'
                            })

                        }

                    }
                })
            },


        }


    }
</script>

<style scoped>


    .cover-size {
        display: block;
        height: 280px;
        width: 200px;

    }

    .modal-card {
        width: auto;
    }

    .column-flex {
        flex-grow: 0 !important;
        -webkit-flex-grow: 0 !important;
    }

    .button-color {
        background-color: #18303e;
        text-decoration-color: white
    }

    .button-color-red {
        background-color: darkred;
        text-decoration-color: white
    }


</style>