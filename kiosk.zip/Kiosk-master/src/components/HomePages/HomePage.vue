<template>
    <section>
        <div class="gap" v-if="hasLogin">

            <b-autocomplete
                    rounded
                    type="text"
                    v-model="search"
                    icon="magnify"
                    placeholder="Pesquisa...">
            </b-autocomplete>


        </div>

        <div style="margin: 4%">
            <hr v-if="hasLogin" class="category-separator">
            <div class="columns">
                <div class="column is-7 is-5-mobile">
                    <h1 class="has-text-left title" style="margin-bottom: 2%" v-if="this.books.length!==0">Livros</h1>
                </div>

                <div class="column is-4 is-2-mobile has-text-right " v-if="hasLogin">
                    <b-dropdown>
                        <button class="button is-dialog" slot="trigger">
                            <span>Ordenar</span>
                            <b-icon icon="menu-down"></b-icon>
                        </button>
                        <b-dropdown-item @click="orderByName">Ordenar por nome A--Z</b-dropdown-item>
                        <b-dropdown-item @click="orderByName2" >Ordenar por nome Z--A</b-dropdown-item>
                        <!--<b-dropdown-item @click="orderByName3" >Ordenar por Avaliação Positiva</b-dropdown-item>
                        <b-dropdown-item @click="orderByName4" >Ordenar por Avaliação Negativa</b-dropdown-item>-->
                    </b-dropdown>

                </div>

            </div>
            <div class="columns is-multiline">
                <div class="column column-flex" v-for="(book, index) in filteredList">
                    <div class="card ">
                        <div class="card-image cursor cover-size">
                            <div class="container" @click="open(book)">
                                <img :src="book.img" class="cover-size">
                                <div class="overlay">
                                    <i class="mdi mdi-magnify has-text-white"></i>
                                </div>
                            </div>


                        </div>
                        <footer class="card-footer">
                            <a class="card-footer-item button-color" v-if="hasLogin && book.number>0"
                               @click="addReserve(book)"><b>Reservar</b></a>
                            <a class="card-footer-item button-color is-disabled" v-if="hasLogin && book.number<=0"
                               ><b>Indisponível</b></a>
                            <a class="card-footer-item button-color" v-if="hasLogin"
                               @click="addFav(book)"><b>Guardar</b></a>
                            <a class="card-footer-item button-color" v-if="hasAdminLogin"
                               @click="openEdit(book)"><b>Editar</b></a>
                            <a class="card-footer-item button-color-red" @click="remove(book,index)"
                               v-if="hasAdminLogin"><b>Remover</b></a>
                        </footer>
                    </div>
                </div>


                <div class="column column-flex" v-if="hasAdminLogin">
                    <div class="card ">
                        <div class="card-image cursor cover-size" @click="createBook">
                            <div class="container cover-size">
                                <i id="plus" class="mdi mdi-plus"></i>
                                <div class="overlay-plus">
                                    <i class="mdi mdi-plus has-text-white"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="center-screen-desktop" v-if="this.books.length===0">
                <h1 class="title has-text-centered">Não há livros disponíveis</h1>
            </div>

        </div>
        <app-modal v-if="this.$store.getters['getOpen']"></app-modal>
        <app-add v-if="this.$store.getters['getOpenAdd']"></app-add>
        <app-edit v-if="this.$store.getters['getOpenEdit']"></app-edit>
    </section>
</template>

<script>

    import {openModal} from '../../mixins/modal/open.js'
    import {openAdd} from '../../mixins/modal/openAdd.js'
    import {openEdit} from '../../mixins/modal/openEdit.js'
    import BookModal from './../HomePages/BookModal.vue'
    import AddBook from './../HomePages/AddBook.vue'
    import EditBook from './../HomePages/EditBook.vue'

    export default {
        name: "HomePage",
        mixins: [openModal, openAdd, openEdit],
        components: {
            'app-modal': BookModal,
            'app-add': AddBook,
            'app-edit': EditBook


        },
        data: function () {
            return {
                books: JSON.parse(localStorage.getItem("books")),
                user: JSON.parse(sessionStorage.getItem("isLogged")),
                users: JSON.parse(localStorage.getItem("usersList")),
                search: '',
                search2: '',
                /*magazines: JSON.parse(localStorage.getItem("magazines")),*/
                hasLogin: sessionStorage.isLogged,
                hasAdminLogin: sessionStorage.adminIsLogged,
                isOpen: false
                // isAdmin:localStorage.isLogged.name
            };
        },

        created() {
            console.log(this.books)
            if(this.hasLogin&&this.user[0].notif.length!==0){

                for(let i =0; i<this.user[0].notif.length; i++){


                }


            }
        },

        methods: {
            remove(book, index) {

                this.$dialog.confirm({
                    title: `Apagar Livro`,
                    message: `Tem a certeza que pretende <b>apagar</b> ${book.title}?`,
                    confirmText: 'Apagar Livro',
                    cancelText: 'Cancelar',
                    type: 'is-danger-dialog',
                    hasIcon: true,
                    onConfirm: () => {
                        this.books.splice(index, 1);
                        localStorage.setItem("books", JSON.stringify(this.books));
                    }
                })

            },

            addFav(book) {

                const title = book.title
                let bookExists = false
                for (let i = 0; i < this.user[0].favs.length; i++) {

                    if (title === this.user[0].favs[i].title) {
                        this.$toast.open({
                            message: `${book.title} já foi adicionado aos favoritos`,
                            type: 'is-danger-dialog'
                        })
                        bookExists = true


                    }

                }
                if (!bookExists) {
                    console.log(book)
                    this.$toast.open({
                        message: `${book.title} adicionado aos favoritos`,
                        type: 'is-success'
                    })
                    this.user[0].favs.push(book)
                    sessionStorage.setItem("isLogged", JSON.stringify(this.user))

                    let res = this.users.map(obj => this.user.find(o => o.email === obj.email) || obj);
                    console.log(res);
                    localStorage.setItem("usersList", JSON.stringify(res))
                }


            },


            addReserve(book) {

                book.number = book.number-1
                this.user[0].reserves.push(book)
                sessionStorage.setItem("isLogged", JSON.stringify(this.user))

                let res = this.users.map(obj => this.user.find(o => o.email === obj.email) || obj);
                console.log(res);
                localStorage.setItem("usersList", JSON.stringify(res))

                let res2 = this.books.map(obj => this.user[0].reserves.find(o => o.id === obj.id) || obj);
                console.log(res2);
                localStorage.setItem("books", JSON.stringify(res2))

                this.$toast.open({
                    message: `A sua reserva foi recebida pelo administrador`,
                    type: 'is-success'
                })


            },
            removeFav(index) {

                this.$dialog.confirm({
                    title: `Apagar Livro`,
                    message: 'Tem a certeza que pretende <b>apagar</b> este livro?',
                    confirmText: 'Apagar Livro',
                    cancelText: 'Cancelar',
                    type: 'is-danger-dialog',
                    hasIcon: true,
                    onConfirm: () => {
                        this.books.splice(index, 1);
                        localStorage.setItem("books", JSON.stringify(this.books));
                    }
                })

            },

            compareName(a, b) {
                if (a.title < b.title) return -1
                if (a.title > b.title) return 1
                else return 0
            },
            orderByName() {
                this.books.sort(this.compareName)
            },

            compareName2(a, b) {
                if (a.title > b.title) return -1
                if (a.title < b.title) return 1
                else return 0
            },
            orderByName2() {
                this.books.sort(this.compareName2)
            },
            /*compareName3(a, b) {
                if (a.score < b.score) return -1
                if (a.score > b.score) return 1
                else return 0
            },
            orderByName3() {
                this.books.sort(this.compareName3)
            },
            compareName4(a, b) {
                if (a.score > b.score) return -1
                if (a.score < b.score) return 1
                else return 0
            },
            orderByName4() {
                this.books.sort(this.compareName4)
            },*/




        },

        computed: {


            filteredList() {

                return this.books.filter(books => {
                    return books.title.toLowerCase().includes(this.search.toLowerCase());
                });
            }

        }


    }

</script>

<style scoped>


    .category-separator {
        margin-left: 10%;
        margin-right: 10%;
    }

    .cover-size {
        display: block;
        height: 280px;
        width: 200px;

    }

    .column-flex {
        flex-grow: 0 !important;
        -webkit-flex-grow: 0 !important;
    }

    .cursor {
        cursor: pointer;
    }

    .button-color {
        background-color: #18303e;
        text-decoration-color: white
    }

    .button-color-red {
        background-color: darkred;
        text-decoration-color: white
    }

    .gap {
        margin-top: 40px;
        margin-left: 20%;
        margin-right: 20%;
    }

    .container {
        position: relative;
        width: 100%;
    }

    .overlay {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        height: 100%;
        width: 100%;
        opacity: 0;
        transition: .3s ease;
        background-color: #18303e;
    }

    .overlay-plus {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        height: 100%;
        width: 100%;
        opacity: 0;
        transition: .3s ease;
        background-color: #18303e;
    }

    .container:hover .overlay {
        opacity: 0.7;
    }

    .container:hover .overlay-plus {
        opacity: 1;
    }

    .mdi-magnify {

        font-size: 100px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        text-align: center;
    }

    .mdi-plus {

        font-size: 100px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        text-align: center;
    }

    #plus {
        color: #18303e;
        font-size: 100px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        text-align: center;
    }

    .center-screen-desktop {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);

    }

    .search {
        opacity: 0.5;
    }

    .search:hover {
        opacity: 1;
        text-decoration-color: #18303e;
    }


</style>