<template>
    <section style="font-size: 20px;">
        <!--Modal-->
        <div class="modal is-active">
            <div class="modal-background"></div>
            <div class="modal-card">
                <header class="modal-card-head" style=" background-color: #18303e">
                    <p class="modal-card-title has-text-left has-text-white">
                        Editar Livro
                    </p>
                    <button class="delete" aria-label="close" @click="close"></button>
                </header>
                <section class="modal-card-body">
                    <div class="columns">

                        <!--Desktop-->
                        <div class="column is-4 ">
                            <img class="cover-size" width="150" :src="book.img">
                            <p class="has-text-black p-padding"><b>Link da Imagem</b></p>
                            <b-input type="text" v-model="book.img"></b-input>


                        </div>

                        <div class="column has-text-left">
                            <p class="has-text-black p-padding"><b>Titulo</b></p>
                            <b-input v-model="book.title"></b-input>
                            <p class="has-text-black padding"><b>Autores</b></p>
                            <b-input v-model="book.author"></b-input>
                            <p class="has-text-black p-padding"><b>Descrição</b></p>
                            <b-input type="textarea" v-model="book.description"></b-input>
                            <p class="has-text-black p-padding"><b>ISBN</b></p>
                            <b-input v-model="book.ISBN"></b-input>
                            <p class="has-text-black p-padding"><b>Idioma</b></p>
                            <b-input v-model="book.idiom"></b-input>
                            <p class="has-text-black p-padding"><b>Exemplares disponíves</b></p>
                            <b-input type="number" v-model="book.number"></b-input>

                            <button class="button button-color has-text-white " @click="editBook(book)">
                                Editar Livro
                            </button>

                        </div>
                    </div>
                </section>

            </div>
        </div>


    </section>
</template>

<script>
    import {openEdit} from '../../mixins/modal/openEdit.js'


    export default {
        name: "EditModal",
        mixins: [openEdit],
        data() {
            return {
                books: JSON.parse(localStorage.getItem("books")),
                book: this.$store.getters['getSelectedBook'],



            }
        },



        methods: {


            editBook(book) {






                /*this.book.push(this.bookForm)*/

               let res2 = this.books.map(x => x.id == book.id ? book : x)
                console.log(res2);
                localStorage.setItem("books", JSON.stringify(res2))

                this.$dialog.alert({
                    title: "Sucesso",
                    type: 'is-success',
                    message: "Livro atualizado com sucesso",
                   /* onConfirm: () => window.location.pathname = '/'*/

                })


            }


        },

    }
</script>

<style scoped>

    .cover-size {
        height: 280px;
        width: 200px;

    }

    .p-padding {
        padding-bottom: 10px;
    }

    .button-color {
        background-color: #18303e;
        margin-top: 20px;
    }


</style>