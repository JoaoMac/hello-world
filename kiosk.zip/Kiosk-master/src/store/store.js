import Vue from 'vue'
import Vuex from 'vuex'
import open from './modules/open'
import openAdd from './modules/openAdd'
import openEdit from './modules/openEdit'
import selectedSolution from './modules/selectedBook'
import selectedUser from './modules/selectedUser'

Vue.use(Vuex)

export default new Vuex.Store({
    modules: {
        openEdit,
        openAdd,
        open,
        selectedSolution,
        selectedUser

    }
})
