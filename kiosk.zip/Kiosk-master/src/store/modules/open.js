// initial state
const state = {
    isOpened: false
}

// getters
const getters = {
    getOpen(state, getters) {
        return state.isOpened
    },

}

// mutations
const mutations = {
    setOpen(state, newValue) {
        state.isOpened = newValue;
    },

}

export default {
    state,
    getters,
    mutations
}