// initial state
const state = {
    selectedUser: [],

}

// getters
const getters = {

    getSelectedUser(state, getters) {
        return state.selectedUser
    },

}

// actions

// mutations
const mutations = {

    setSelectedUser(state, selectedUser) {
        state.selectedUser = selectedUser
    },


}


export default {
    state,
    getters,
    mutations
}