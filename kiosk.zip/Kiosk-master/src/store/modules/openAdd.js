// initial state
const state = {
    isOpenedAdd: false
}

// getters
const getters = {
    getOpenAdd(state, getters) {
        return state.isOpenedAdd
    },

}

// mutations
const mutations = {
    setOpenAdd(state, newValue) {
        state.isOpenedAdd= newValue;
    },

}

export default {
    state,
    getters,
    mutations
}