// initial state
const state = {
    selectedBook: [],

}

// getters
const getters = {

    getSelectedBook(state, getters) {
        return state.selectedBook
    },

}

// actions

// mutations
const mutations = {

    setSelectedBook(state, selectedBook) {
        state.selectedBook = selectedBook
    },


}


export default {
    state,
    getters,
    mutations
}