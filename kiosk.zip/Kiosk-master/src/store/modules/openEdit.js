// initial state
const state = {
    isOpenedEdit: false
}

// getters
const getters = {
    getOpenEdit(state, getters) {
        return state.isOpenedEdit
    },

}

// mutations
const mutations = {
    setOpenEdit(state, newValue) {
        state.isOpenedEdit = newValue;
    },

}

export default {
    state,
    getters,
    mutations
}