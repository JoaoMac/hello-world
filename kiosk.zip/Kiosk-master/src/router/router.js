import Vue from 'vue'
import Router from 'vue-router'
import HomePageUser from '../components/HomePages/HomePage.vue'
import Login from '../components/Forms/Login.vue'
import SignUp from '../components/Forms/SignUp.vue'
import Favorites from '../components/ProfilePages/Favorites.vue'
import Profile from '../components/ProfilePages/Profile.vue'
import Reserves from '../components/ProfilePages/Reserves.vue'
import Users from '../components/ProfilePages/Users.vue'


Vue.use(Router)

export default new Router({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'HomePage',
            component:HomePageUser
        },
        {
            path: '/login',
            name: 'Login',
            component:Login
        },
        {
            path: '/signup',
            name: 'SignUp',
            component:SignUp
        },


        {
            path: '/favorites',
            name: 'Favorites',
            component:Favorites
        },

        {
            path: '/reserves',
            name: 'Reserves',
            component:Reserves
        },
        {
            path: '/users',
            name: 'Users',
            component:Users
        },
        {
            path: '/profile',
            name: 'Profile',
            component:Profile
        },






    ]
})