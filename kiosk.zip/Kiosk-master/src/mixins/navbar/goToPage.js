export const goToPage = {
    methods: {
        goToPage(route) {
            this.$router.push(route)
            this.showMobileMenu=false

        }
    }
}
