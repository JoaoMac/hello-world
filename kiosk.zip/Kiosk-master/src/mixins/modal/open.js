
export const openModal = {
    methods: {
        open(book) {

            this.$store.commit('setSelectedBook',book)
            this.$store.commit('setOpen', true)

        },

        //carregar na cruz do modal
        close() {
            //fecha o modal
            this.$store.commit('setOpen', false)

        }
    }
}