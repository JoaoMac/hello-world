
export const openReserves = {
    methods: {
        openReserves(user) {

            this.$store.commit('setSelectedUser',user)
            this.$store.commit('setOpen', true)

        },

        //carregar na cruz do modal
        close() {
            //fecha o modal
            this.$store.commit('setOpen', false)

        }
    }
}