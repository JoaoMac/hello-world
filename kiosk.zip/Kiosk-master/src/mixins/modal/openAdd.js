export const openAdd = {
    methods: {
        createBook() {
            this.$store.commit('setOpenAdd', true)
        },
        //carregar na cruz do modal
        close() {
            //fecha o modal
            this.$store.commit('setOpenAdd', false)

        }
    }
}