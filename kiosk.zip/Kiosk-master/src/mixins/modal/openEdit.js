
export const openEdit = {
    methods: {
        openEdit(book) {

            this.$store.commit('setSelectedBook',book)
            this.$store.commit('setOpenEdit', true)

        },

        //carregar na cruz do modal
        close() {
            //fecha o modal
            this.$store.commit('setOpenEdit', false)

        }
    }
}