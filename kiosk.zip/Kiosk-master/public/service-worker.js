workbox.core.setCacheNameDetails({prefix: "PWA"});

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [].concat(self.__precacheManifest || []);
workbox.precaching.suppressWarnings();
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});

workbox.precaching.precache([
    '/img/icons/apple-touch-icon.png',
    '/img/icons/apple-touch-icon-57x57.png',
    '/img/icons/apple-touch-icon-72x72.png',
    '/img/icons/apple-touch-icon-76x76.png',
    '/img/icons/apple-touch-icon-114x114.png',
    '/img/icons/apple-touch-icon-120x120.png',
    '/img/icons/apple-touch-icon-114x114.png',
    '/img/icons/apple-touch-icon-152x152.png',
    '/img/icons/apple-touch-icon-180x180.png',
    '/img/icons/android-chrome-192x192.png',
    '/img/icons/android-chrome-512x512.png',
    '/img/icons/favicon-16x16.png',
    '/img/icons/favicon-32x32.png',
    '/img/icons/mstile-150x150.png',
    '/img/icons/safari-pinned-tab.svg',

]);

// Caching Routes
workbox.precaching.precacheAndRoute([

    {
        "revision": "1",
        "url": "/"
    },
    {
        "revision": "2",
        "url": "/"
    }


], {});
