# projeto-Kiosk

<p align="center">
  <img src="./src/assets/images/logo/logo.png" alt="Build Status">


## Description
* **A web book store to view and reserve all the books and magazines available at the ESMAD library**

* **Includes:app config files, mixins, router (vue-router), modular store (Vuex)**

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint

### Dependencies

```
"axios": "^0.18.0",
"buefy": "^0.6.6",
"vue": "^2.5.17",
"vue-router": "^3.0.1",
"vuex": "^3.0.1",
"register-service-worker": "^1.0.0"
```

### Dev dependencies

```
"@vue/cli-plugin-babel": "^3.0.1",
"@vue/cli-plugin-pwa": "^3.0.3",
"@vue/cli-service": "^3.0.1",
"jest": "^23.6.0",
"node-sass": "^4.9.0",
"sass-loader": "^7.0.1",
"vue-template-compiler": "^2.5.17"
```

```
### Authors

* **Miguel Silva**
